package Run;

import mapreduce.KMeansMapper;
import mapreduce.KMeansReducer;
import model.Helper;
import model.KMeansCanopyCenter;
import model.Stock;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;

public class KMeansClusteringJob extends Configured implements Tool {
	
	//private static final Log LOG = LogFactory.getLog(KMeansClusteringJob.class);
	Configuration config;
	Job job;
	boolean lastIteration;
	
	public KMeansClusteringJob()
	{
		lastIteration = false;
	}
	
	@Override
	public int run(String[] args) throws Exception {
		int k;
		
		config = new Configuration();
		k = Integer.parseInt(args[2]);
		if(args.length>3)
			config.setFloat(Helper.t1, Float.parseFloat(args[3]));
		else
			config.setFloat(Helper.t1, 32.0f);
		if(args.length>4)
			config.setFloat(Helper.t2, Float.parseFloat(args[4]));
		else
			config.setFloat(Helper.t2, 5.0f);
		
		//set job Paths
		Path in = new Path(args[0]);
		Path out = new Path(args[1]);
		Path seq = new Path(in.getParent().toString(), Helper.canopyCentroidName);
		
		config.set(Helper.canopyCentroidPath, seq.toString());
		config.setInt(Helper.kValue, k);
		config.setBoolean(Helper.lastIteration, lastIteration);
		
		job = new Job(config);
		job.setJobName("Canopy Clustering");
	
		FileSystem fs = FileSystem.get(config);

		if(fs.exists(out))
			fs.delete(out, true);

		
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
		job.setMapperClass(KMeansMapper.class);
		job.setReducerClass(KMeansReducer.class);
		job.setJarByClass(KMeansMapper.class);
		
		
		job.setOutputKeyClass(KMeansCanopyCenter.class);
		job.setOutputValueClass(Stock.class);
		
		job.setMapOutputKeyClass(KMeansCanopyCenter.class);
		job.setMapOutputValueClass(Stock.class);
		
		FileInputFormat.setInputPaths(job, in);
		FileOutputFormat.setOutputPath(job, out);
		
		job.waitForCompletion(true);
		return 0;
	}
	
	public Configuration getConfiguration()
	{
		return config;
	}
	
	public Job getJob()
	{
		return job;
	}
	
	public void setLastIteration(boolean last)
	{
		lastIteration = last;
	}
	
	public boolean isLastIteration()
	{
		return lastIteration;
	}
}
