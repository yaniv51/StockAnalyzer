package Run;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import mapreduce.CanopyMapper;
import mapreduce.CanopyReducer;
import model.CanopyCenter;
import model.Helper;
import model.KMeansCanopyCenter;
import model.KMeansCenter;
import model.Stock;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BooleanWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;

public class CanopyClusteringJob extends Configured implements Tool {

	Configuration config;
	ArrayList<KMeansCanopyCenter> kMeansCenters;
	
	public CanopyClusteringJob()
	{
		kMeansCenters = new ArrayList<KMeansCanopyCenter>();
	}
	
	@Override
	public int run(String[] args) throws Exception {
		int k;
		
		config = new Configuration();
		//get k configuration
		k = Integer.parseInt(args[2]);
		
		if(args.length>3)
			config.setFloat(Helper.t1, Float.parseFloat(args[3]));
		else
			config.setFloat(Helper.t1, 32.0f);
		if(args.length>4)
			config.setFloat(Helper.t2, Float.parseFloat(args[4]));
		else
			config.setFloat(Helper.t2, 5.0f);
		
		//set job Paths
		Path in = new Path(args[0]);
		Path out = new Path(args[1]);
		Path seq = new Path(in.getParent().toString(), Helper.canopyCentroidName);
		
		config.set(Helper.canopyCentroidPath, seq.toString());
		config.setInt(Helper.kValue, k);
		config.setInt(Helper.maxNeighbors, k-1);
		
		Job job = new Job(config);
		job.setJobName("Canopy Clustering");
	
		FileSystem fs = FileSystem.get(config);

		if (fs.exists(seq))
			fs.delete(seq, true);
		if(fs.exists(out))
			fs.delete(out, true);
		
		SequenceFile.Writer writer = SequenceFile.createWriter(config, SequenceFile.Writer.file(seq),
	               SequenceFile.Writer.compression(SequenceFile.CompressionType.RECORD, new GzipCodec()),
	               SequenceFile.Writer.keyClass(BooleanWritable.class), SequenceFile.Writer.valueClass(CanopyCenter.class));
		writer.close();
		
		job.setMapperClass(CanopyMapper.class);
		job.setReducerClass(CanopyReducer.class);
		job.setJarByClass(CanopyMapper.class);
		
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
		job.setOutputKeyClass(BooleanWritable.class);
		job.setOutputValueClass(CanopyCenter.class);
		
		job.setMapOutputValueClass(CanopyCenter.class);
		job.setMapOutputKeyClass(BooleanWritable.class);

		FileInputFormat.setInputPaths(job, in);
		FileOutputFormat.setOutputPath(job, out);
		
		job.waitForCompletion(true);
		return 0;
	}
	
	public Configuration getConfiguration()
	{
		return config;
	}
	
	/**
	 * Get CanopyCenter array and calculate needed K-Means centers
	 * @param list - list of Canopy Centers
	 * @param totalStocks - number of total stocks
	 * @param k - needed new centers
	 */
	public void fixCenters(ArrayList<CanopyCenter> list, int totalStocks, int k)
	{
		int currentNeeded, currentSelected, totalSelected;
		CanopyCenter canopyC;
		KMeansCanopyCenter kCenter;
		
		totalSelected = 0;
		
		//sort array by smallest counter
		Collections.sort(list, new Comparator<CanopyCenter>() {
			public int compare(CanopyCenter c1, CanopyCenter c2)
			{
				return c1.getCounter() - c2.getCounter();
			}
		});
		
		for(int i = 0; i< list.size(); i++)
		{
			canopyC = list.get(i);
			
			currentSelected = 0;
			//calculate percent
			double result = canopyC.getCounter()*1.0 / totalStocks;
			result*=k;
			if(result < 1)
				currentNeeded = 1;
			else
				currentNeeded = (int)Math.round(result);
			kCenter = new KMeansCanopyCenter(new KMeansCenter(canopyC), canopyC);
			if(k-totalSelected == 0)
				break;
			kMeansCenters.add(kCenter);
			currentSelected++;
			totalSelected++;
			if(currentNeeded == currentSelected)
				continue;
			//if needed, select from neighbor stocks
			for(int index = 0; index < currentNeeded-currentSelected; index++)
			{
				if(index>canopyC.getNeighborSize() || k-totalSelected == 0)
					break;
				Stock s = canopyC.getNeighbor(index);
				if(s != null)
				{
					kMeansCenters.add(new KMeansCanopyCenter(new KMeansCenter(s), canopyC));
					totalSelected++;
				}
				else
					break;
			}
		}
		
		clearNeighbors(list);
		clearKNeighbors(kMeansCenters);
	}
	
	private void clearNeighbors(ArrayList<CanopyCenter> list)
	{
		for(CanopyCenter c : list)
		{
			c.setCounter(0);
			c.clearNeighbors();
		}
	}
	
	private void clearKNeighbors(ArrayList<KMeansCanopyCenter> list)
	{
		for(KMeansCanopyCenter c : list)
		{
			c.getCanopyCenter().clearNeighbors();
			c.getCanopyCenter().setCounter(0);
			c.getKMeansCenter().setCounter(0);
		}
	}
	
	public ArrayList<KMeansCanopyCenter> getFixedCenterList()
	{
		return kMeansCenters;
	}
}
