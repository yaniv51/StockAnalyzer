package Run;

import java.io.IOException;
import java.util.ArrayList;

import model.CanopyCenter;
import model.Helper;
import model.KMeansCanopyCenter;
import model.Stock;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BooleanWritable;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.util.ReflectionUtils;
import org.apache.hadoop.util.ToolRunner;

/**
 * @author Israel Yaniv & Koby Osterman & Tal Kramer &Or Tal
 *This class is the Main driver of the Entire project.
 *Responsible to run canopyClustering and kmeansCLustering.
 */
public class MyJob {
	private static final Log LOG = LogFactory.getLog(CanopyClusteringJob.class);	
	ArrayList<CanopyCenter> canopyCenters;
	ArrayList<KMeansCanopyCenter> kMeansCenters;
	CanopyClusteringJob canopyJob;
	KMeansClusteringJob kmeansJob;
	
	//KMeansClusteringJob kmeansJob;
	Configuration config;
	int k, totalStocks, totalSelected, totalCanopyCenters;
	
	public MyJob()
	{
		k = 0;
		totalStocks = 0;
		totalSelected = 0;
		totalCanopyCenters = 0;
		canopyCenters = new ArrayList<CanopyCenter>();
	}
	
	public int runConopyJob(String[] args) throws Exception
	{
		try 
		{
			int res;
			CanopyCenter canopyC;
		    canopyJob = new CanopyClusteringJob();
			k = Integer.parseInt(args[2]);
			res = ToolRunner.run(new Configuration(), canopyJob, args);
			
			config = canopyJob.getConfiguration();
			Path centroidPath = new Path(config.get(Helper.canopyCentroidPath)); 
		    SequenceFile.Reader reader = new SequenceFile.Reader(config, SequenceFile.Reader.file(centroidPath));
		    BooleanWritable key = (BooleanWritable) ReflectionUtils.newInstance(reader.getKeyClass(), config);
		    CanopyCenter value = (CanopyCenter) ReflectionUtils.newInstance(reader.getValueClass(), config);
		    LOG.info("start read canopy");
		    while (reader.next(key, value)) {
		    	LOG.info(value.toString());
		    	canopyC = new CanopyCenter(value);
		    	canopyCenters.add(canopyC);
		    	totalStocks += value.getCounter();
		    	totalCanopyCenters++;
		    }
		    LOG.info("end read canopy");
		    IOUtils.closeStream(reader);
		    
		    canopyJob.fixCenters(canopyCenters, totalStocks, k);
		    kMeansCenters = canopyJob.getFixedCenterList();
		    writeCanopyCenters(kMeansCenters, config);
		    
		    return res;
		}
		catch (Exception e) {
			Exception ex = new Exception("Failed to run Canopy Clustering", e);
			throw ex;
		}
	}
	
	private int runKmeansJob(String[] args) throws Exception {
		
		try
		{
			int res = 0, iteration = 0;
			long counter = 1; //count changes per run
			kmeansJob = new KMeansClusteringJob();
			kmeansJob.setLastIteration(false);
			while(counter!=0)
			{
				res = ToolRunner.run(new Configuration(), kmeansJob, args);
				counter = kmeansJob.getJob().getCounters().findCounter(Helper.Counter.CHANGE).getValue();
				iteration++;
				LOG.info("ITERATION "+iteration);
			}
			
			kmeansJob.setLastIteration(true);
			res = ToolRunner.run(new Configuration(), kmeansJob, args);
		    return res;

		}
		catch (Exception e) {
			Exception ex = new Exception("Failed to run K-Means Clustering", e);
			throw ex;
		}
	}
	
	private void writeCanopyCenters(ArrayList<KMeansCanopyCenter> list, Configuration jobConfig) throws IOException {
		FileSystem fs = FileSystem.get(config);
		Path outPath = new Path(jobConfig.get(Helper.canopyCentroidPath));
		if (fs.exists(outPath))
			fs.delete(outPath, true);
		SequenceFile.Writer writer = SequenceFile.createWriter(jobConfig, SequenceFile.Writer.file(outPath),
	               SequenceFile.Writer.compression(SequenceFile.CompressionType.RECORD, new GzipCodec()),
	               SequenceFile.Writer.keyClass(KMeansCanopyCenter.class), SequenceFile.Writer.valueClass(Stock.class));
		for(KMeansCanopyCenter k :list)
		{
			LOG.info(k.toString());
			writer.append(k, new Stock());
		}
		writer.close();
	}
	
	public static void main(String[] args) 
	{
		int res = 1;

		try
		{	
			//check input arguments
		    if (args.length < 3) {
		      System.out.printf(
		          "Usage: Canopy <input dir> <output dir> <K>\n");
		      System.exit(-1);
		    }
		    
		    MyJob job = new MyJob();
		    res = job.runConopyJob(args);  
		    res = job.runKmeansJob(args);
	    
		} catch (Exception e) 
		{
			e.printStackTrace();
			System.exit(res);
		}
		finally
		{
			System.exit(res);
		}
	}

}
