package mapreduce;

import java.io.IOException;
import java.util.ArrayList;

import model.CanopyCenter;
import model.Center;
import model.Helper;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BooleanWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapreduce.Reducer;
/**
 * This class is the Canopy reducer which will run another canopy clustering.
 *
 */
public class CanopyReducer extends Reducer<BooleanWritable, CanopyCenter, BooleanWritable, CanopyCenter> {

	ArrayList<CanopyCenter> centers;
	float t1, t2;
	int maxNeighbors;
	
	public CanopyReducer()
	{
		super();
		centers = new ArrayList<CanopyCenter>();
	}
	
	@Override
	protected void setup(Context context) throws IOException,
	InterruptedException {
		Configuration conf = context.getConfiguration();
		t1 = conf.getFloat(Helper.t1, Helper.difaultT1);
		t2 = conf.getFloat(Helper.t1, Helper.difaultT2);
		maxNeighbors = conf.getInt(Helper.maxNeighbors, 4);
	}
	
	/**
	 * The reducer function which is responsible for finding the real canopy centers.
	 */
	@Override
	protected void reduce(BooleanWritable key, Iterable<CanopyCenter> values,
			Context context) throws IOException, InterruptedException {
		double distance;
		boolean possibleCenter = false;

		//Run another canopy job for all input - if received input from multiple computers/multiple files
		for(CanopyCenter value : values)
		{
			if(centers.size() > 0)
			{
				possibleCenter = false;
				for(CanopyCenter center : centers)
				{
					distance = center.measureDistance(value);
					//The neighbors are possible centers in the kmeans algorithm.
					if(distance < t2 || distance<t1)
						center.addNeighbor(value.getStocks());
					if(distance < t2)
					{
						possibleCenter = false;	
						break;
						
					}
					else if(distance < t1)
					{
						center.incCounter(value.getCounter());
						possibleCenter = false;	
						break;
					}
					else if(distance > t1)
						possibleCenter = true;
				}
				if(possibleCenter)
				{
					addNewCluster(value);
				}
			}
			else
			{
				addNewCluster(value);
				continue;
			}
		}
	}
	
	@Override
	//write canopy centers into new SequenceFile file and to regular output file
	protected void cleanup(Context context)throws IOException, InterruptedException
	{	
		super.cleanup(context);
		Configuration conf = context.getConfiguration();
		Path outPath = new Path(conf.get(Helper.canopyCentroidPath));
		SequenceFile.Writer writer = SequenceFile.createWriter(conf, SequenceFile.Writer.file(outPath),
	               SequenceFile.Writer.compression(SequenceFile.CompressionType.RECORD, new GzipCodec()),
	               SequenceFile.Writer.keyClass(BooleanWritable.class), SequenceFile.Writer.valueClass(CanopyCenter.class));

		final BooleanWritable key = new BooleanWritable(true);
		for(CanopyCenter c : centers)
		{
			context.write(key, c);
			writer.append(key, c);
		}
		writer.close();
	}
	
	private Center addNewCluster(CanopyCenter center)
	{
		CanopyCenter newCenter = new CanopyCenter(center);
		newCenter.setMaxNeighbors(maxNeighbors);
		centers.add(newCenter);
		return newCenter;
	}
}
