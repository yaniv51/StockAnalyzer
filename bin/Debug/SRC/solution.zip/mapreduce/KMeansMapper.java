package mapreduce;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import model.CanopyCenter;
import model.Helper;
import model.KMeans;
import model.KMeansCanopyCenter;
import model.Stock;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.util.ReflectionUtils;

/**
 * This is the KMeansmapper class which is responsible for running a kmeans algorithm on the canopy centers.
 */
public class KMeansMapper extends Mapper<LongWritable, Text, KMeansCanopyCenter, Stock> {

	private HashMap<Integer, CanopyCenter> canopyCenterList; //maps from canopy center hash code to canopy center.
	private HashMap<Integer, KMeans> canopyToKcenters; //maps from canopy center hash code to kmeans center that belong to this canopy.
	private HashMap<KMeansCanopyCenter, Stock> kCenterToStock; //maps from Kmeans center to the stocks that belong to the center.
	private Boolean lastIteration;
	private float t2;
	
	public KMeansMapper()
	{
		canopyCenterList = new HashMap<Integer, CanopyCenter>();
		canopyToKcenters = new HashMap<Integer, KMeans>();
		kCenterToStock = new HashMap<KMeansCanopyCenter, Stock>();
		lastIteration = false;
	}

	@Override
	protected void setup(Context context) throws IOException,InterruptedException {
		super.setup(context);
		Configuration config;
		ArrayList<KMeansCanopyCenter> centers;
		
		//reads the Configuration for the config file.
		config = context.getConfiguration();
		t2 = config.getFloat(Helper.t2, Helper.difaultT2);
		lastIteration = config.getBoolean(Helper.lastIteration, true);
		//reads the centers from the sequence file.
		centers = readCenters(context);
		//matching each  k center to each canopy center.
	    for(int key : canopyCenterList.keySet())
	    {
	    	CanopyCenter center = canopyCenterList.get(key);
	    	canopyToKcenters.put(key, new KMeans(center, centers));
	    }
	}
	
	//read previews centers
	private ArrayList<KMeansCanopyCenter> readCenters(Context context) throws IOException
	{
		Configuration config;
		ArrayList<KMeansCanopyCenter> kmeansCenters;
		KMeansCanopyCenter center;
		Path centroidPath;
		
		config = context.getConfiguration();
		kmeansCenters = new ArrayList<KMeansCanopyCenter>();
		centroidPath = new Path(config.get(Helper.canopyCentroidPath));
		
	    SequenceFile.Reader reader = new SequenceFile.Reader(config, SequenceFile.Reader.file(centroidPath));
	    
	    KMeansCanopyCenter key = (KMeansCanopyCenter) ReflectionUtils.newInstance(reader.getKeyClass(), config);
	    Stock value = (Stock) ReflectionUtils.newInstance(reader.getValueClass(), config);
	    while (reader.next(key, value)) {
	    	center = new KMeansCanopyCenter(key);
	    	//add canopy center if not exist
	    	int hashCode = center.getCanopyCenter().hashCode();
	    	if(!canopyCenterList.containsKey(hashCode))
	    		canopyCenterList.put(hashCode, new CanopyCenter(center.getCanopyCenter()));

	    	kmeansCenters.add(center);
	    	//System.out.println("add new k-map center: " + center.toString());
	    	kCenterToStock.put(center, new Stock());
	    }
	    IOUtils.closeStream(reader);
	    return kmeansCenters;
	}
	
	/**
	 * map function which counts the stocks to their kmeans centers.	
	 */
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException 
	{
		double distance, nearestDistance;
		boolean firstLoop;
		CanopyCenter nearestCanopyCenter, canopyCenter;
		KMeansCanopyCenter currentCenter;
		
		String valueString = value.toString();
		firstLoop = true;
		nearestCanopyCenter = null;
		nearestDistance = Double.MAX_VALUE;
		
		for(String line : valueString.split("\n"))
		{
			//find canopy center
			Stock newStock = new Stock(line);
			
			for(int newKey : canopyCenterList.keySet())
			{
				canopyCenter = canopyCenterList.get(newKey);
				distance = canopyCenter.measureDistance(newStock);
				if(firstLoop)
				{
					nearestCanopyCenter = canopyCenter;
					nearestDistance = distance;
					firstLoop = false;
				}
				//ignore stock if smaller than T2
				if(distance < t2)
					return;
				//use this canopy center if smaller than nearest canopy center
				if(distance < nearestDistance)
				{
					nearestCanopyCenter = canopyCenter;
					nearestDistance = distance;
					break;
				}
			}
			currentCenter = canopyToKcenters.get(nearestCanopyCenter.hashCode()).getNearestKCenter(newStock);
			if(lastIteration)
			{
				kCenterToStock.get(currentCenter).appendName(newStock.getName());
			}
			else
			{
				kCenterToStock.get(currentCenter).addVectorData(newStock.getVector());
				kCenterToStock.get(currentCenter).incCounter(1);
			}
		}
	}

	@Override
	protected void cleanup(Context context) throws IOException,InterruptedException {
		try
		{
			Stock kStock;
			for(int kmeansKey : canopyToKcenters.keySet())
			{
				KMeans kmeans = canopyToKcenters.get(kmeansKey);
				for(KMeansCanopyCenter center : kmeans.getCenters())
				{
					kStock = kCenterToStock.get(center);
					context.write(center, kStock);
				}
			}
		}
		catch(Exception ex)
		{
			
		}
		super.cleanup(context);
	}
}