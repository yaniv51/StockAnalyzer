package mapreduce;

import java.io.IOException;
import java.util.ArrayList;

import model.Helper;
import model.KMeansCanopyCenter;
import model.Stock;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapreduce.Reducer;

/**
 * This is the Kmeans Reducer class which is responsible for calculating the average for each k center.
 */
public class KMeansReducer extends Reducer<KMeansCanopyCenter, Stock, KMeansCanopyCenter, Stock> {

	ArrayList<KMeansCanopyCenter> allCenters;
	Boolean lastIteration;
	
	public KMeansReducer()
	{
		allCenters = new ArrayList<KMeansCanopyCenter>();
		lastIteration = false;
	}
	
	@Override
	protected void setup(Context context) throws IOException,
	InterruptedException {
		Configuration config = context.getConfiguration();
		lastIteration = config.getBoolean(Helper.lastIteration, true);
		FileSystem fs = FileSystem.get(config);
		Path outPath = new Path(config.get(Helper.canopyCentroidPath));
		
		//remove old sequence file for rewrite
		if (fs.exists(outPath))
			fs.delete(outPath, true);
	}

	/**
	 * This method calculates the average for each k center.
	 */
	@Override
	protected void reduce(KMeansCanopyCenter key, Iterable<Stock> values, Context context) throws IOException, InterruptedException 
	{
		int counter;
		Stock currentStock;
		boolean firstLoopIteration;
		
		firstLoopIteration = true;
		counter = 0;
		currentStock = null;
		
		for(Stock value : values)
		{
			if (firstLoopIteration) {
				currentStock =new Stock(value);
				counter+=value.getCounter();
				firstLoopIteration = false;
				continue;
			}
			//for the last iteration append the name.
			if(lastIteration)
			{
				currentStock.appendName(value.getName());
			}
			//otherwise, adds the stock data.
			else
			{
				currentStock.addVectorData(value.getVector());
				counter+=value.getCounter();
			}
		}
		if(!lastIteration)
		{
			currentStock.SetAvarage(counter);
			//check converge 
			if(currentStock.checkConverged(key.getKMeansCenter().getStocks()) != 0)
				context.getCounter(Helper.Counter.CHANGE).increment(1);
			
			if(currentStock.getVector().size() > 0)
				key.getKMeansCenter().setStocks(currentStock);
		}
		else
		{
			if(currentStock.getName().length() == 0)
				currentStock.appendName(key.getKMeansCenter().getStocks().getName());
		}
		
		allCenters.add(new KMeansCanopyCenter(key));
		//save updated center
		context.write(key,currentStock);
	}
	
	
	@Override
	protected void cleanup(Context context)throws IOException, InterruptedException
	{
		//append updated center to local sequenceFile
		Configuration conf = context.getConfiguration();
		Path outPath = new Path(conf.get(Helper.canopyCentroidPath));
		SequenceFile.Writer writer;
		
		writer = SequenceFile.createWriter(conf, SequenceFile.Writer.file(outPath),
		           SequenceFile.Writer.compression(SequenceFile.CompressionType.RECORD, new GzipCodec()),
		           SequenceFile.Writer.keyClass(KMeansCanopyCenter.class), SequenceFile.Writer.valueClass(Stock.class));


		final Stock value = new Stock();
		for(KMeansCanopyCenter key : allCenters)
		{
			writer.append(key, value);
		}

		writer.close();
	}
}
