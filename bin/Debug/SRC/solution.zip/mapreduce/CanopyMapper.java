package mapreduce;

import java.io.IOException;
import java.util.ArrayList;

import model.CanopyCenter;
import model.Center;
import model.Helper;
import model.Stock;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.BooleanWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * This class is the CanopyMapper which is responsible for mapping the stocks .
 *
 */
public class CanopyMapper extends Mapper<LongWritable, Text, BooleanWritable, CanopyCenter>  {

	ArrayList<CanopyCenter> centers;
	float t1, t2;
	
	public CanopyMapper()
	{
		super();
		centers = new ArrayList<CanopyCenter>();
	}
	
	@Override
	protected void setup(Context context) throws IOException,
	InterruptedException {
		Configuration conf = context.getConfiguration();
		t1 = conf.getFloat(Helper.t1, Helper.difaultT1);
		t2 = conf.getFloat(Helper.t1, Helper.difaultT2);
	}
	
	/**
	 * This is the map function which will find which stock will be a center.
	 * counts the number of stocks inside a center.
	 */
	@Override
	protected void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		boolean possibleCenter = false;
		double distance;
		
		String valueString = value.toString();
		
		for(String line : valueString.split("\n"))
		{
			Stock newStock = new Stock(line);
			if(centers.size() != 0)
			{
				for(Center c : centers)
				{
					distance = c.measureDistance(newStock);
					if(distance < t2)
					{
						possibleCenter = false;
						break;
					}
					else if(distance < t1)
					{
						c.incCounter(1);
						possibleCenter = false;
						break;
					}
					else if(distance > t1)
					{
						//mark this vector as possible center
						possibleCenter = true;
					}
				}
				
				if(possibleCenter)
					addNewCenter(newStock);
			}
			else
			{
				addNewCenter(newStock);
				continue;
			}
		}
	}
	
	/**
	 * This method writes the centers to the reducer.
	 */
	@Override
	protected void cleanup(Context context)throws IOException, InterruptedException
	{
		super.cleanup(context);	
		for(CanopyCenter c : centers){
			context.write(new BooleanWritable(true), c);
		}
	}
	
	//this method adds a new center to the array centers.
	private Center addNewCenter(Stock value)
	{
		CanopyCenter newCenter = new CanopyCenter(value);
		
		centers.add(newCenter);
		return newCenter;
	}	
}
