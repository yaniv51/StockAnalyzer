package model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

/**
 * This class represents a stock which is a center.
 */
public class Center implements WritableComparable<Center> {

	protected Stock center;
	private int counter;

	public Center() {
		super();
		this.center = new Stock();
		counter = 0;
	}
	
	public Center(String stockName)
	{
		super();
		this.center = new Stock(stockName, true);
		counter = 0;
	}

	public Center(Stock stock) {
		super();
		this.center = new Stock(stock);
		counter = 1;
	}
	
	public Center(Center newCenter)
	{
		super();
		this.center = newCenter.center;
		counter = newCenter.counter;
	}

	@Override
	public void write(DataOutput out) throws IOException {
		center.write(out);
		out.writeInt(counter);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		this.center = new Stock();
		center.readFields(in);
		counter = in.readInt();
	}

	
	public int getCounter() {
		return counter;
	}
	
	public void setCounter(int value) {
		counter = value;
	}
	
	public void incCounter(int value)
	{
		counter+=value;
	}
	
	public double measureDistance(Stock stock)
	{
		return center.measureDistance(stock);
	}
	
	
	public void AddStockData(Stock newStock)
	{
		counter++;
		center.addVectorData(newStock.getVector());
	}

	@Override
	public int compareTo(Center o) {
		return center.compareTo(o.center);
	}
	
	public Stock getStocks()
	{
		return center;
	}
	
	public Center clone()
	{
		return new Center(this);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((center == null) ? 0 : center.hashCode());
		result = prime * result + counter;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Center other = (Center) obj;
		if (center == null) {
			if (other.center != null)
				return false;
		} else if (!center.equals(other.center))
			return false;
		if (counter != other.counter)
			return false;
		return true;
	}
	
	public void setStocks(Stock otherStock)
	{
		otherStock.setName(center.getName());
		center = new Stock(otherStock);
		counter = 0;
		center.resetCounter();
	}
	
}
