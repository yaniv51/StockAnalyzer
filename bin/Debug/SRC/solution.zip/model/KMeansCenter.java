package model;

public class KMeansCenter extends Center {

	public KMeansCenter()
	{
		super();
	}
	
	public KMeansCenter(Stock s)
	{
		super(s);
	}
	
	public KMeansCenter(KMeansCenter newKCenter) {
		super(newKCenter.center);
	}
	
	public KMeansCenter(CanopyCenter canopyCenter)
	{
		super(canopyCenter.getStocks());
	}

	@Override
	public String toString() {
		return "KMeansCenter [stock: "+super.getStocks().toString()+ "]";
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
	
	
	
	
}