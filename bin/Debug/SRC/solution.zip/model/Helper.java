package model;

public final class Helper {
	
	public static final String iteration = "num.iteration";
	public static final String t1 = "distance.T1";
	public static final String t2 = "distance.T2";
	public static final String centroidPath = "centroid.path";
	public static final String canopyCentroidPath = "canopyCentroid.path";
	public static final String canopyCentroidName = "import/canopyCentroid.seq";
	public static final String lastIteration = "last.iteration";
	public static final String maxNeighbors = "max.neighbors";
	public static final String kValue = "k.value";
	public static enum Counter {CHANGE}
	public static final float difaultT1 = 16.0f;
	public static final float difaultT2 = 5.0f;
}
