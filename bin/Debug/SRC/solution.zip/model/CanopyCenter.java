package model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;

public class CanopyCenter extends Center {
	
	private ArrayList<Stock> neighborVectors;
	int maxNeighbors;
	
	public CanopyCenter() {
		super();
		neighborVectors = new ArrayList<Stock>();
	}

	public CanopyCenter(Stock stocks)
	{
		super(stocks);
		neighborVectors = new ArrayList<Stock>();
	}
	
	public CanopyCenter(CanopyCenter newCanopyCenter)
	{
		super(newCanopyCenter.clone());
		neighborVectors = newCanopyCenter.getNeighborList();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		super.write(out);
		out.writeInt(neighborVectors.size());
		for(Stock neighbor : neighborVectors)
			neighbor.write(out);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		super.readFields(in);
		neighborVectors = new ArrayList<Stock>();
		int neighborSize = in.readInt();
		for(int i =0; i< neighborSize; i++)
		{
			Stock v = new Stock();
			v.readFields(in);
			neighborVectors.add(v);
		}
	}
	
	public void setNeighborList(ArrayList<Stock> neighbors)
	{
		neighborVectors = neighbors;
	}
	
	public void addNeighbor(Stock s)
	{
		if(neighborVectors.size() >= maxNeighbors)
			return;
		neighborVectors.add(s);
	}
	
	public Stock getNeighbor(int index)
	{
		if(index >= neighborVectors.size())
			return null;
		return neighborVectors.get(index);
	}
	
	public int getNeighborSize()
	{
		return neighborVectors.size();
	}
	
	public ArrayList<Stock> getNeighborList()
	{
		return neighborVectors;
	}
	
	public void clearNeighbors()
	{
		neighborVectors.clear();
	}

	@Override
	public int getCounter() {
		return super.getCounter();
	}

	@Override
	public void setCounter(int value) {
		super.setCounter(value);
	}

	@Override
	public void incCounter(int value) {
		super.incCounter(value);
	}

	@Override
	public double measureDistance(Stock stock) {
		return super.measureDistance(stock);
	}
	
	public double measureDistance(CanopyCenter newCenter)
	{
		return super.measureDistance(newCenter.getStocks());
	}

	@Override
	public int compareTo(Center o) {
		return super.compareTo(o);
	}

	@Override
	public String toString() {
		return "CanopyCenter [stock: "+super.getStocks().toString() + neighborVectors + "]";
	}
	
	public Center getCenter()
	{
		return super.clone();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((neighborVectors == null) ? 0 : neighborVectors.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CanopyCenter other = (CanopyCenter) obj;
		if (neighborVectors == null) {
			if (other.neighborVectors != null)
				return false;
		} else if (!neighborVectors.equals(other.neighborVectors))
			return false;
		return true;
	}
	
	public int getMaxNeighbors()
	{
		return maxNeighbors;
	}
	
	public void setMaxNeighbors(int value)
	{
		maxNeighbors = value;
	}
}
