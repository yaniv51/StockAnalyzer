package model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class KMeansCanopyCenter implements WritableComparable<KMeansCanopyCenter> {

	private KMeansCenter kCenter;
	private CanopyCenter canopyCenter;
	
	public KMeansCanopyCenter()
	{
		kCenter = new KMeansCenter();
		canopyCenter = new CanopyCenter();
	}
	
	public KMeansCanopyCenter(KMeansCenter newKCenter, CanopyCenter newCanopyCenter)
	{
		kCenter = new KMeansCenter(newKCenter);
		canopyCenter = new CanopyCenter(newCanopyCenter);
	}
	
	public KMeansCanopyCenter(KMeansCanopyCenter key) {
		this(key.kCenter, key.canopyCenter);
	}

	@Override
	public void write(DataOutput out) throws IOException {
		kCenter.write(out);
		canopyCenter.write(out);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		kCenter.readFields(in);
		canopyCenter.readFields(in);
	}

	@Override
	public int compareTo(KMeansCanopyCenter o) {
		int sum = 0;
		sum = canopyCenter.compareTo(o.canopyCenter); 
		if( sum != 0)
			return sum;
		sum = kCenter.compareTo(o.kCenter);
		return sum;
	}

	@Override
	public String toString() {
		return "KMeansCanopyCenter [canopyCenter="+ canopyCenter + ",kCenter + " + kCenter+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((canopyCenter == null) ? 0 : canopyCenter.hashCode());
		result = prime * result + ((kCenter == null) ? 0 : kCenter.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		KMeansCanopyCenter other = (KMeansCanopyCenter) obj;
		if (canopyCenter == null) {
			if (other.canopyCenter != null)
				return false;
		} else if (!canopyCenter.equals(other.canopyCenter))
			return false;
		if (kCenter == null) {
			if (other.kCenter != null)
				return false;
		} else if (!kCenter.equals(other.kCenter))
			return false;
		return true;
	}

	public KMeansCenter getKMeansCenter()
	{
		return kCenter;
	}
	
	public CanopyCenter getCanopyCenter()
	{
		return canopyCenter;
	}
	
}
