package model;

import java.util.ArrayList;

/**
 * This class represents an array of kmeans centers for each canopy.
 */
public class KMeans {

	private ArrayList<KMeansCanopyCenter> centers;
	
	//each object will be created for each CanopyCenter
	public KMeans()
	{
		centers = new ArrayList<KMeansCanopyCenter>();
	}
	
	public KMeans(CanopyCenter canopyCenter, ArrayList<KMeansCanopyCenter> kCenters) {
		this();
		KMeansCanopyCenter newCenter;
		//filter KMeansCenters by received canopy center
		for(int index = 0; index < kCenters.size(); index ++)
		{
			newCenter = kCenters.get(index);
			if(newCenter.getCanopyCenter().compareTo(canopyCenter) == 0)
				centers.add(newCenter);
		}
	}

	//This function finds the nearest center.
	public KMeansCanopyCenter getNearestKCenter(Stock stock)
	{
		double minDistance, distance;
		KMeansCanopyCenter nearestCenter, center;
		boolean firstIteration = true;
		
		minDistance = Double.MAX_VALUE;
		nearestCenter = null;
		
		for(int i = 0; i< centers.size(); i++)
		{
			center = centers.get(i);
			distance = center.getKMeansCenter().measureDistance(stock);
			if(firstIteration)
			{
				nearestCenter = center;
				minDistance = distance;
				firstIteration = false;
				continue;
			}
			
			if(distance < minDistance)
			{
				nearestCenter = center;
				minDistance = distance;
			}
		}
		
		return nearestCenter;
	}
	
	public ArrayList<KMeansCanopyCenter> getCenters()
	{
		return centers;
	}
	
	
}
