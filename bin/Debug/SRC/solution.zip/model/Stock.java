package model;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

public class Stock implements  WritableComparable<Stock> {

	private Text name;
	private ArrayList<Double> stocks;
	private int counter;
	
	public Stock()
	{
		name = new Text();
		stocks = new ArrayList<Double>();
		counter = 0;
	}
	
	public Stock(String stockName, boolean isName)
	{
		name = new Text(stockName);
		stocks = new ArrayList<Double>();
		counter = 0;
	}
	
	public Stock(Stock stock)
	{
		name = new Text(stock.name);
		stocks = new ArrayList<Double>();
		counter = stock.counter;
		for(Double value : stock.stocks)
		{
			stocks.add(value);
		}
	}
	
	public Stock(String tStockData)
	{
		int stockParams;
		String[] stockData, stockInfo;
		stocks = new ArrayList<Double>();
		counter = 0;
		stockData = tStockData.split("\\|");
		stockInfo =  stockData[0].split(",");
		name = new Text(stockInfo[0]);
		stockParams = Integer.parseInt(stockInfo[1]);
		createStockData(stockData[1], stockParams);
	}
	
	private void createStockData(String stockData, int stockParams)
	{
		String[] splitedStockData, tempData;
		splitedStockData = stockData.split(";");
		
		for(String stock : splitedStockData)
		{
			tempData = stock.split(",");
			for(String data : tempData)
			{
				if(!data.isEmpty())
					stocks.add(Double.parseDouble(data));
			}
		}
	}
	
	@Override
	public void write(DataOutput out) throws IOException {
		int stocksSize;
		name.write(out);
		out.writeInt(counter);
		stocksSize = stocks.size();
		out.writeInt(stocksSize);
		for(int index = 0; index < stocksSize; index++)
			out.writeDouble(stocks.get(index));
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		int stocksSize;
		double value;
		name.readFields(in);
		counter = in.readInt();
		stocksSize = in.readInt();
		stocks = new ArrayList<Double>();
		for(int index = 0; index < stocksSize; index++)
		{
			value = in.readDouble();
			stocks.add(value);
		}
	}

	public double measureDistance(ArrayList<Double> otherVector)
	{
		try
		{
		double distance = 0;
		for(int i=0; i < this.stocks.size(); i++) {
			if(otherVector.size() < i)
				continue;
			distance += Math.abs(this.stocks.get(i) - otherVector.get(i));
		}
		return distance;
		}
		catch(Exception ex)
		{
			return 0;
		}
	}
	
	@Override
	public int compareTo(Stock o) {
		double distance = 0;
		if(o.stocks.size() == 0)
			return 1;
		for(int index = 0; index < stocks.size(); index++)
		{
			if(index >= o.stocks.size())
				continue;
			distance = this.stocks.get(index) - o.stocks.get(index);
			if(distance < 0)
				return -1;
			else if(distance > 0)
				return 1;
		}
		return 0;
	}
	
	
	
	@Override
	public String toString() {
		return name.toString();
	}

	public String vectorToString() {
		StringBuilder sb = new StringBuilder();
		
		for(int i=0; i < stocks.size(); i++) {
			sb.append(Double.toString(stocks.get(i)));
			if(i < stocks.size() - 1)
				sb.append(',');
		}	
		return sb.toString();
	}
	
	public void addVectorData(ArrayList<Double> vector)
	{
		if(stocks.size() == 0)
		{
			for(int index = 0; index < vector.size(); index++)
			{
				stocks.add(vector.get(index));
			}
			return;
		}
		
		for(int index = 0; index < stocks.size(); index++)
		{
			if(index >= vector.size())
				continue;
			stocks.set(index, stocks.get(index)+vector.get(index));
		}
	}
	

	public double measureDistance(Stock stock) 
	{
		return this.measureDistance(stock.stocks);
	}

	public ArrayList<Double> getVector() {
		return stocks;
	}
	
	public void incCounter(int value)
	{
		counter += value;
	}
	
	public int getCounter()
	{
		return counter;
	}
	
	public void SetAvarage(int sum)
	{
		for(int index = 0; index < stocks.size(); index++)
		{
			stocks.set(index, stocks.get(index)/sum);
		}
			
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + counter;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((stocks == null) ? 0 : stocks.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Stock other = (Stock) obj;
		if (counter != other.counter)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (stocks == null) {
			if (other.stocks != null)
				return false;
		} else if (!stocks.equals(other.stocks))
			return false;
		return true;
	}
	
	public float checkConverged(Stock otherStock) {
		double c;
		for (int i = 0; i < stocks.size(); i++) {
			if(otherStock.stocks.size() < i)
				continue;
			c = Math.abs(stocks.get(i) - otherStock.stocks.get(i));
			if (c!= 0.0d)
			{
				return (float)c;
			}
		}
		return 0;
	}
	
	public void setName(String newName)
	{
		this.name = new Text(newName);
	}
	
	public String getName()
	{
		return name.toString();
	}
	
	public void resetCounter()
	{
		counter = 0;
	}
	
	public void appendName(String additionName)
	{
		StringBuilder sb = new StringBuilder();
		sb.append(name.toString());
		if(sb.length() > 0 && additionName.length() > 0)
			sb.append(",");
		sb.append(additionName);
		
		name = new Text(sb.toString());
	}
}